//
//  LoginViewController.swift
//  QRCodeProject
//
//  Created by Xuân Quỳnh Lê on 8/27/17.
//  Copyright © 2017 Quynhlx. All rights reserved.
//

import UIKit
import TextFieldEffects

class LoginViewController: UIViewController, UITextFieldDelegate {

    @IBOutlet var txtNumberPhone: HoshiTextField!
    @IBOutlet var txtPassword: HoshiTextField!
    
    @IBOutlet var btnLogin: UIButton!
    @IBOutlet var btnRegister: UIButton!
    
    @IBOutlet var btnResetPassword: UIButton!
    
    @IBAction func resetButtonTouched(_ sender: Any) {
        
            let vc =  PopupHelper.showPopupFromStoryBoard(storyBoard: "Main", popupName: "ResetPasswordWebVCIdentifier", viewController: self, blurBackground: true) as! ResetPopUpViewController
        
            vc.url = Utils.web_reset_pass
        
    }
    
    @IBAction func onLoginTouched(_ sender: Any) {
        //check input
        if checkForErrors() {
            return
        }
        
        self.view.endEditing(true)
        
        let  key : UInt64 = UInt64(NSDate().timeIntervalSince1970 * 1000 * 13 + 27)
        
        //request to server
        Utils.showHUD(title: nil, view: self.view)
        
        AppServices.requestLogin(phone: txtNumberPhone.text!, pass: txtPassword.text!, key: Int64(key)) { [weak self] (error, loginVO) -> String in
            
            
            guard let strongSelf = self else {
                return ""
            }
            
            Utils.hideHUD(view: strongSelf.view)
            
            if let error = error {
                Utils.showMessage(title: "Error", message: error.localizedDescription)
            }else {
                if loginVO?.status == Utils.SUCCESS {
                    Utils.setLoginStatus(status: true)
                    
                    //save user_id
                    Utils.setUserId(status: (loginVO?.user_id)!)
                    
                    // open scanner screen
                    strongSelf.performSegue(withIdentifier: "showTabarIdentifier", sender: nil)
                }  else if loginVO?.status == Utils.FAILED {
                    Utils.alertWithTitle(title: "Lỗi đăng nhập", message: (loginVO?.message)!, ViewController: strongSelf, toFocus:strongSelf.txtPassword)
                    
                    Utils.setLoginStatus(status: false)
                }
                
//                print("RESPONSE: \(String(describing: loginVO))")
//                Utils.setLoginStatus(status: true)
                
                //save user_id
//                Utils.setUserId(status: (loginVO?.user_id)!)
//
//                //Utils.showMessage(title: registerModel?.status, message: registerModel?.message)
//                // open scanner screen
//                strongSelf.performSegue(withIdentifier: "showTabarIdentifier", sender: nil)
                
                
            }
            
            if loginVO == nil {
                return ""
            }
            else {
                return (loginVO?.message)!
            }
        }
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        self.txtNumberPhone.resignFirstResponder()
        self.txtPassword.resignFirstResponder()
        
        return true
    }
    
    func textFieldShouldClear(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        
        if (textField == self.txtNumberPhone) {
            self.txtNumberPhone.becomeFirstResponder()
        }
        else if (textField == self.txtPassword) {
            self.txtPassword.becomeFirstResponder()
        }
        else{
            let thereWereErrors = checkForErrors()
            if !thereWereErrors
            {
                //conditionally segue to next screen
            }
        }
        
        return true
    }
    
    func checkForErrors() -> Bool
    {
        var errors = false
        let title = NSLocalizedString("login_title", comment: "login title")
        var message = ""
        
        if (txtNumberPhone.text?.isEmpty)!
        {
            errors = true
            message += NSLocalizedString("login_null_phone_title", comment: "login_null_phone_title login title")//"Vui lòng nhập số điện thoại"
            Utils.alertWithTitle(title: title, message: message, ViewController: self, toFocus:self.txtNumberPhone)
            
        }
        else if (txtPassword.text?.isEmpty)!
        {
            errors = true
            message += NSLocalizedString("login_null_password_title", comment: "login_password_title login title")//"Vui lòng nhập mật khẩu"
            Utils.alertWithTitle(title: title, message: message, ViewController: self, toFocus:txtPassword)
        }
        else if (txtPassword.text?.utf16.count)! < 6
        {
            errors = true
            message += NSLocalizedString("login_password_than6_title", comment: "login_password_title login title")//"Mật khẩu phải lớn hơn 4 ký tự"
            Utils.alertWithTitle(title: title, message: message, ViewController: self, toFocus:self.txtPassword)
        }
        
        return errors
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        txtNumberPhone.delegate = self
        txtPassword.delegate = self
        
        txtNumberPhone.keyboardType = UIKeyboardType.numberPad
        
        txtNumberPhone.placeholder = NSLocalizedString("txtNumberPhoneHolder", comment: "number Phone Holder")
        txtPassword.placeholder = NSLocalizedString("txtPasswordHolder", comment: "txt Password Holder")
        
        btnLogin.setTitle(NSLocalizedString("btnLoginTitle", comment: "Title for Button login"), for: UIControlState.normal)
        btnRegister.setTitle(NSLocalizedString("login_btnRegisterTitle", comment: "Title for register login"), for: UIControlState.normal)
        
        btnResetPassword.setTitle(NSLocalizedString("login_btnResetPassword", comment: "Title for btnResetPassword login"), for: UIControlState.normal)
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        self.txtNumberPhone.becomeFirstResponder
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        super.prepare(for: segue, sender: sender)
        if segue.identifier == "showResetWebviewIdentifier" {
            let vc = segue.destination as! WebviewViewController
            vc.url = sender as! String
        }
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
