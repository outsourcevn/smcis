//
//  SettingTableViewController.swift
//  QRCodeProject
//
//  Created by Xuân Quỳnh Lê on 8/28/17.
//  Copyright © 2017 Quynhlx. All rights reserved.
//

import UIKit

class SettingTableViewController: UITableViewController {

    @IBOutlet var lbUserInfo: MCAutolocalizedLabel!
    @IBOutlet var lbLogout: MCAutolocalizedLabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        lbUserInfo.text = NSLocalizedString("setting_lbUserInfo", comment: "lbUserInfo text")
        lbLogout.text = NSLocalizedString("setting_lbLogout", comment: "lbLogout text ")
        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if indexPath.row == 0 {
            //edit infor
        } else if indexPath.row == 2 {
            //change language
            let refreshAlert = UIAlertController(title: NSLocalizedString("setting_change_lang", comment: "setting_choice_lang text")/*"Thay đổi ngôn ngữ"*/, message: NSLocalizedString("setting_choice_lang", comment: "setting_choice_lang text")/*"Chọn lựa ngôn ngữ"*/, preferredStyle: UIAlertControllerStyle.alert)
            
            refreshAlert.addAction(UIAlertAction(title: NSLocalizedString("setting_vietnam", comment: "setting_choice_lang text")/*"Tiếng Việt"*/, style: .default, handler: { (action: UIAlertAction!) in
                Utils.setLanguages(status: "vi")
                MCLocalization.sharedInstance.language = "vi"
                
            }))
            
            refreshAlert.addAction(UIAlertAction(title: NSLocalizedString("setting_english", comment: "setting_english text")/*"Tiếng Anh"*/, style: .default, handler: { (action: UIAlertAction!) in
                Utils.setLanguages(status: "en")
                MCLocalization.sharedInstance.language = "en"
                
            }))
            
            present(refreshAlert, animated: true, completion: nil)
        } else if indexPath.row == 1 {
            //Logout
            let refreshAlert = UIAlertController(title: NSLocalizedString("setting_change_logout", comment: "chane hi")/*"Đăng xuất"*/, message: NSLocalizedString("setting_logout_status_confirm", comment: "setting_english text")/*"Bạn có muốn đăng xuất không?"*/, preferredStyle: UIAlertControllerStyle.alert)
            
            refreshAlert.addAction(UIAlertAction(title: NSLocalizedString("setting_accept", comment: "Đồng ý text")/*"Đồng ý"*/, style: .default, handler: { (action: UIAlertAction!) in
                //set ve trang thai chua login
                Utils.setLoginStatus(status: false)
                Utils.setUserId(status: "")
                Utils.setTutorialShow(show: true)
                
               //Mo man hinh dang nhap
                let mainStoryboard = UIStoryboard(name: "Main", bundle: Bundle.main)
                let vc : UIViewController = mainStoryboard.instantiateViewController(withIdentifier: "LoginVC") as UIViewController
                self.present(vc, animated: true, completion: nil)
            }))
            
            refreshAlert.addAction(UIAlertAction(title: NSLocalizedString("setting_cancel", comment: "quay lai text")/*"Quay lại"*/, style: .cancel, handler: { (action: UIAlertAction!) in
                
            }))
            
            present(refreshAlert, animated: true, completion: nil)
            
//            Utils.showMessage(title: "Message", message: "Ban co muon dang xuat")
            
        }
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return 2
    }

    override func awakeFromNib() {
        super.awakeFromNib()
        
        self.title = NSLocalizedString("tabBarSetting", comment: "tabBarSetting title")
        
    }
    
    /*
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "reuseIdentifier", for: indexPath)

        // Configure the cell...

        return cell
    }
    */

    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
