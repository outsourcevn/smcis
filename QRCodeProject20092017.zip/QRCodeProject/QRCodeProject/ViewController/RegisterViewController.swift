//
//  RegisterViewController.swift
//  QRCodeProject
//
//  Created by Xuân Quỳnh Lê on 8/27/17.
//  Copyright © 2017 Quynhlx. All rights reserved.
//

import UIKit
import TextFieldEffects

class RegisterViewController: UIViewController, UITextFieldDelegate {
    @IBOutlet var txtUserName: HoshiTextField!
   
    @IBOutlet var txtEmail: HoshiTextField!
   
    @IBOutlet var txtPhoneNumber: HoshiTextField!
    
    @IBOutlet var txtPassword: HoshiTextField!
    
    @IBOutlet var txtRePassword: HoshiTextField!            
    
    @IBOutlet var btnCreateAccount: UIButton!
    
    @IBOutlet var btnLogin: UIButton!
    
    func textFieldShouldClear(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        if (textField == self.txtUserName) {
            self.txtUserName.becomeFirstResponder()
        }
        else if (textField == self.txtEmail) {
            self.txtEmail.becomeFirstResponder()
            
        } else if (textField == self.txtPhoneNumber) {
            self.txtPhoneNumber.becomeFirstResponder()
        } else if (textField == self.txtPassword) {
            self.txtPassword.becomeFirstResponder()
        }else if (textField == self.txtRePassword) {
            self.txtRePassword.becomeFirstResponder()
        }
        else{
            let thereWereErrors = checkForErrors()
            if !thereWereErrors
            {
                //conditionally segue to next screen
            }
        }
        
        return true
    }
    
    func checkForErrors() -> Bool
    {
        var errors = false
        let title =  NSLocalizedString("login_title", comment: "login title")
        var message = ""
        if (txtUserName.text?.isEmpty)! {
            errors = true
            message += NSLocalizedString("register_null_username_title", comment: "register_null_username_title login title")//"Vui lòng nhập họ tên của bạn"
            Utils.alertWithTitle(title: title, message: message, ViewController: self, toFocus:self.txtUserName)
            
        }
        else if (txtEmail.text?.isEmpty)!
        {
            errors = true
            message +=  NSLocalizedString("register_null_email_title", comment: "register_null_email_title login title")//"Vui lòng nhập địa chỉ Email"
            Utils.alertWithTitle(title: title, message: message, ViewController: self, toFocus:self.txtEmail)
            
            self.txtEmail.becomeFirstResponder()
        }
        else if !(Utils.isValidEmail(email: txtEmail.text!))
        {
            errors = true
            message += NSLocalizedString("register_error_email_title", comment: "register_error_email_title login title")//"Địa chỉ Email không chính xác"
            Utils.alertWithTitle(title: title, message: message, ViewController: self, toFocus:self.txtEmail)
            
        }
        else if (txtPhoneNumber.text?.isEmpty)!
        {
            errors = true
            message += NSLocalizedString("register_null_phone_title", comment: "register_null_phone_title login title")//"Vui lòng nhập số điện thoại"
            Utils.alertWithTitle(title: title, message: message, ViewController: self, toFocus:self.txtPhoneNumber)
            
        }
        else if (txtPassword.text?.isEmpty)!
        {
            errors = true
            message += NSLocalizedString("register_null_password_title", comment: "register_null_password_title login title")//"Vui lòng nhập mật khẩu"
            Utils.alertWithTitle(title: title, message: message, ViewController: self, toFocus:txtPassword)
        }
        else if (txtPassword.text?.utf16.count)! < 6
        {
            errors = true
            message += NSLocalizedString("register_6_password_title", comment: "register_6_password_title login title") //"Mật khẩu phải lớn hơn 4 ký tự"
            Utils.alertWithTitle(title: title, message: message, ViewController: self, toFocus:self.txtPassword)
        }
        else if (txtRePassword.text?.isEmpty)!
        {
            errors = true
            message += NSLocalizedString("register_re_password_title", comment: "register_re_password_title login title")//"Vui lòng nhập lại mật khẩu"
            Utils.alertWithTitle(title: title, message: message, ViewController: self, toFocus:txtRePassword)
        }
        else if (txtRePassword.text?.utf16.count)! < 6
        {
            errors = true
            message += NSLocalizedString("register_6_password_title", comment: "register_6_password_title login title")//"Mật khẩu phải lớn hơn 4 ksy tự"
            Utils.alertWithTitle(title: title, message: message, ViewController: self, toFocus:self.txtRePassword)
        }
        else if (txtPassword.text != txtRePassword.text) {
            errors = true
            message += NSLocalizedString("register_password_not_pare_title", comment: "register_password_not_pare_title login title")//"Mật khẩu không khớp"
            Utils.alertWithTitle(title: title, message: message, ViewController: self, toFocus:self.txtRePassword)
        }
        return errors
    }        
    

    @IBAction func onRegisterTouched(_ sender: Any) {
        //check input
        if checkForErrors() {
            return
        }
        
        self.view.endEditing(true)
        
        let  key : UInt64 = UInt64(NSDate().timeIntervalSince1970 * 1000 * 13 + 27)
        
        //request to server
        Utils.showHUD(title: nil, view: self.view)
        
        AppServices.requestRegister(name: txtUserName.text!, email: txtEmail.text!, phone: txtPhoneNumber.text!, pass: txtPassword.text!, user_id: 0, key: Int64(key)) { [weak self] (error, registerModel) -> String in
            
            
            guard let strongSelf = self else {
                return ""
            }
            
            Utils.hideHUD(view: strongSelf.view)
            
            if let error = error {
                Utils.showMessage(title:  NSLocalizedString("login_title", comment: "login title"), message: error.localizedDescription)
            }else {
             
                //set dang nhap thanh cong
                if registerModel?.status == Utils.SUCCESS {
                    Utils.setLoginStatus(status: true)
                    
                    //save user_id
                    Utils.setUserId(status: (registerModel?.user_id)!)
                    
                    // open scanner screen
                    strongSelf.performSegue(withIdentifier: "showFromRegisterTabarIdentifier", sender: nil)
                }  else if registerModel?.status == Utils.FAILED {
                    
                     Utils.alertWithTitle(title: NSLocalizedString("register_login_error_title", comment: "login_password_title login title")/*"Lỗi đăng nhập"*/, message: (registerModel?.message)!, ViewController: strongSelf, toFocus:strongSelf.txtPhoneNumber)
                }
                
            }
            if registerModel == nil {
                return ""
            } else {
                return (registerModel?.message)!
            }
        }
        
        
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        self.txtUserName.resignFirstResponder()
        self.txtEmail.resignFirstResponder()
        self.txtPhoneNumber.resignFirstResponder()
        self.txtPassword.resignFirstResponder()
        self.txtRePassword.resignFirstResponder()
        
        return true
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        txtUserName.delegate = self
        txtEmail.delegate = self
        txtPhoneNumber.delegate = self
        txtPassword.delegate = self
        txtRePassword.delegate = self
        
        txtUserName.keyboardType = UIKeyboardType.namePhonePad
        txtEmail.keyboardType = UIKeyboardType.emailAddress
        txtPhoneNumber.keyboardType = UIKeyboardType.numberPad
        
        self.txtUserName.becomeFirstResponder
        
        txtUserName.placeholder = NSLocalizedString("register_txtUserName", comment: "txtUserName Holder")
        txtEmail.placeholder = NSLocalizedString("register_txtEmail", comment: "txtEmail Holder")
        
        txtPhoneNumber.placeholder = NSLocalizedString("txtNumberPhoneHolder", comment: "number Phone Holder")
        txtPassword.placeholder = NSLocalizedString("txtPasswordHolder", comment: "txtPassword Holder")
        txtRePassword.placeholder = NSLocalizedString("register_txtRePassword", comment: "txtRePassword Holder")
        
        btnCreateAccount.setTitle(NSLocalizedString("register_btnCreateAccount", comment: "Title for btnCreateAccount login"), for: UIControlState.normal)
        
        btnLogin.setTitle(NSLocalizedString("register_btnLogin", comment: "Title for btnLogin login"), for: UIControlState.normal)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func exitAction(sender: AnyObject) {
     self.dismiss(animated: true, completion: nil)
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
