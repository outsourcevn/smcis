//
//  ScanerQrCodeViewController.swift
//  QRCodeProject
//
//  Created by Xuân Quỳnh Lê on 8/27/17.
//  Copyright © 2017 Quynhlx. All rights reserved.
//

import UIKit
import AVFoundation
import CoreLocation
//import STPopup

class ScanerQrCodeViewController: UIViewController,
AVCaptureMetadataOutputObjectsDelegate,
CLLocationManagerDelegate {
    var captureSession:AVCaptureSession?
    var videoPreviewLayer:AVCaptureVideoPreviewLayer?
    var qrCodeFrameView:UIView?
    
    @IBOutlet var scanQrCodeButton: UIButton!
    let locationManager = CLLocationManager()
    var strAdministrativeArea : String?
    var strCountry : String?
    var mCurrentLocation : CLLocation?
//    var bottomPopUp : STPopupController!
    
    //bien xac nhan co the request info tu QrCodeString
    var isRequestDone = true
    
    @IBOutlet var lbTutorial: UILabel!
    @IBOutlet var qrScanerView: UIView!
    
    func requestInfo(qrCodeString: String, fullString: String)-> Void {
        
        if (!isRequestDone) {
            return
        }
        
        isRequestDone = false
        
        //request to server
        Utils.showHUD(title: nil, view: self.view)
        
        let lat = self.mCurrentLocation?.coordinate.latitude ?? 0
        let lon = self.mCurrentLocation?.coordinate.latitude ?? 0
        
        let  key : UInt64 = UInt64(NSDate().timeIntervalSince1970 * 1000 * 13 + 27)
        
        let userId = Int64(Utils.getUserId()) ?? 0
        

        
        if strAdministrativeArea == nil {
            strAdministrativeArea = ""
        }
        
        if strCountry == nil {
            strCountry = ""
        }
        
        AppServices.requestCheckInfo(os: "0", guid: qrCodeString, user_id: userId, lon: lon, lat: lat, address: strAdministrativeArea! + strCountry!, key: Int64(key)) { [weak self] (error, productInfo) -> String in
            guard let strongSelf = self else {
                return ""
            }
            
            strongSelf.isRequestDone = true
            
            Utils.hideHUD(view: strongSelf.view)
            
            if let error = error {
                Utils.showMessage(title: "Error", message: error.localizedDescription)
            }else {
           
                
                if strongSelf.parent != nil {
                   let vc =  PopupHelper.showPopupFromStoryBoard(storyBoard: "Main", popupName: "BottomPopupVCIdentifier", viewController: strongSelf.parent!, blurBackground: false) as! PopupViewController
                    
                    vc.productVO = productInfo
                    vc.fullString = fullString
                    
//                    vc.dismiss(animated: true, completion: {
//                        NSLog("hihii tat")
//                    })
                }
                
//                DispatchQueue.main.async(execute: {
//                    strongSelf.bottomPopUp.present(in: strongSelf)
//                    popup.presentInViewController(self.parentViewController)
//                })
                
                
            }
            
            if productInfo == nil {
                return ""
            } else  {
                return (productInfo?.message)!
            }
        }
    }
    
    @IBAction func onScanOtherProductTouched(_ sender: Any) {
        scanQrCodeButton.isHidden = true
        lbTutorial.isHidden = true
        
        //start captureOutput
        captureSession?.startRunning()
    }
    
    func getQrCodeString(fullString: String) -> String {
        print("fullString: \(fullString)")
        if fullString.characters.count == 0 {
            return ""
        }
        
        if fullString.characters.count > 36 {
        for var i  in 0..<fullString.characters.count - 36 {
            
            print(fullString.substring(i..<i + 36))
            
            let uuid = NSUUID(uuidString: fullString.substring(i..<i + 36))
            
            if uuid != nil {
                return fullString.substring(i..<i + 36)
            }
        }
        }
        return ""
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        locationManager.delegate = self
        locationManager.desiredAccuracy = kCLLocationAccuracyNearestTenMeters
        locationManager.requestWhenInUseAuthorization()
        locationManager.startUpdatingLocation()
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        CLGeocoder().reverseGeocodeLocation(manager.location!, completionHandler: {(placemarks, error)->Void in
            
            if (error != nil) {
                print("Reverse geocoder failed with error" + (error?.localizedDescription)!)
                return
            }
            
            if (placemarks?.count)! > 0 {
                let pm = placemarks?[0]
                self.displayLocationInfo(pm)
                self.mCurrentLocation = manager.location

                
            } else {
                print("Problem with the data received from geocoder")
            }
        })
    }
    
    func displayLocationInfo(_ placemark: CLPlacemark?) {
        if let containsPlacemark = placemark {
            //stop updating location to save battery life
            locationManager.stopUpdatingLocation()
//            let locality = (containsPlacemark.locality != nil) ? containsPlacemark.locality : ""
//            let postalCode = (containsPlacemark.postalCode != nil) ? containsPlacemark.postalCode : ""
            let administrativeArea = (containsPlacemark.administrativeArea != nil) ? containsPlacemark.administrativeArea : ""
            let country = (containsPlacemark.country != nil) ? containsPlacemark.country : ""
            
//            localityTxtField.text = locality
//            postalCodeTxtField.text = postalCode
            strAdministrativeArea = administrativeArea ?? ""
            strCountry = country
        }
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        scanQrCodeButton.isHidden = true
        
        lbTutorial.text = NSLocalizedString("txtTutorial", comment: "txtTutorial show")
        
        if Utils.getTutorialShow() {
            lbTutorial.isHidden = false
            Utils.setTutorialShow(show: false)
        }  else {
            lbTutorial.isHidden = true
        }            
        
        // Do any additional setup after loading the view.
        // Get an instance of the AVCaptureDevice class to initialize a device object and provide the video as the media type parameter.
        let captureDevice = AVCaptureDevice.defaultDevice(withMediaType: AVMediaTypeVideo)
        
        do {
            // Get an instance of the AVCaptureDeviceInput class using the previous device object.
            let input = try AVCaptureDeviceInput(device: captureDevice)
            
            // Initialize the captureSession object.
            captureSession = AVCaptureSession()
            
            // Set the input device on the capture session.
            captureSession?.addInput(input)
            
            // Initialize a AVCaptureMetadataOutput object and set it as the output device to the capture session.
            let captureMetadataOutput = AVCaptureMetadataOutput()
            captureSession?.addOutput(captureMetadataOutput)
            
            // Set delegate and use the default dispatch queue to execute the call back
            captureMetadataOutput.setMetadataObjectsDelegate(self, queue: DispatchQueue.main)
            captureMetadataOutput.metadataObjectTypes = [AVMetadataObjectTypeQRCode]
            
            // Initialize the video preview layer and add it as a sublayer to the viewPreview view's layer.
            videoPreviewLayer = AVCaptureVideoPreviewLayer(session: captureSession)
            videoPreviewLayer?.videoGravity = AVLayerVideoGravityResizeAspectFill
            videoPreviewLayer?.frame = qrScanerView.layer.bounds
            qrScanerView.layer.addSublayer(videoPreviewLayer!)
            
            // Start video capture.
            captureSession?.startRunning()
            
            // Initialize QR Code Frame to highlight the QR code
            qrCodeFrameView = UIView()
            
            if let qrCodeFrameView = qrCodeFrameView {
                qrCodeFrameView.layer.borderColor = UIColor.green.cgColor
                qrCodeFrameView.layer.borderWidth = 2
                
                qrScanerView.addSubview(qrCodeFrameView)
                qrScanerView.bringSubview(toFront: qrCodeFrameView)
            }
            
        } catch {
            // If any error occurs, simply print it out and don't continue any more.
            print(error)
            return
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    func captureOutput(_ captureOutput: AVCaptureOutput!, didOutputMetadataObjects metadataObjects: [Any]!, from connection: AVCaptureConnection!) {
        
        // Check if the metadataObjects array is not nil and it contains at least one object.
        if metadataObjects == nil || metadataObjects.count == 0 {
            qrCodeFrameView?.frame = CGRect.zero
//            messageLabel.text = "No QR code is detected"
            
            return
        }
        
        // Get the metadata object.
        let metadataObj = metadataObjects[0] as! AVMetadataMachineReadableCodeObject
        
        if metadataObj.type == AVMetadataObjectTypeQRCode {
            // If the found metadata is equal to the QR code metadata then update the status label's text and set the bounds
            let barCodeObject = videoPreviewLayer?.transformedMetadataObject(for: metadataObj)
            qrCodeFrameView?.frame = barCodeObject!.bounds
            
            if metadataObj.stringValue != nil {
                //stop captureOutput
                captureSession?.stopRunning()
                scanQrCodeButton.isHidden = false
                
                //get QrcodeString
                let strQrCodeString = metadataObj.stringValue
                    //getQrCodeString(fullString: metadataObj.stringValue)
                
                if !(strQrCodeString?.isEmpty)! {
                    requestInfo(qrCodeString: strQrCodeString!, fullString: metadataObj.stringValue)
                } else {
                    //open webview
                    
                    if verifyUrl(urlString: metadataObj.stringValue) {
                        performSegue(withIdentifier: "showWebviewIdentifier", sender: metadataObj.stringValue)
                    } else {
                        performSegue(withIdentifier: "showWebviewIdentifier", sender: "http://smartcheck.vn/")
                    }
                }
            }
        }
    }
    
    func verifyUrl (urlString: String?) -> Bool {
        //Check for nil
        if let urlString = urlString {
            // create NSURL instance
            if let url = NSURL(string: urlString) {
                // check if your application can open the NSURL instance
                return UIApplication.shared.canOpenURL(url as URL)
            }
        }
        return false
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        super.prepare(for: segue, sender: sender)
        if segue.identifier == "showWebviewIdentifier" {
            let vc = segue.destination as! WebviewViewController
            vc.url = sender as! String
        }
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        
        //layout playframe
        videoPreviewLayer?.frame = qrScanerView.layer.bounds
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        self.title = NSLocalizedString("tabBarScanQrCode", comment: "tabBarScanQrCode title")
    
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
