//
//  PopupHelper.swift
//  QRCodeProject
//
//  Created by Xuân Quỳnh Lê on 9/7/17.
//  Copyright © 2017 Quynhlx. All rights reserved.
//

import Foundation
import STPopup
class PopupHelper {
    
    static func showPopupFromStoryBoard(storyBoard: String, popupName: String, viewController: UIViewController, blurBackground: Bool) -> UIViewController {
        let storyboard = UIStoryboard(name: storyBoard, bundle: nil)
        
        let vc = storyboard.instantiateViewController(withIdentifier: popupName)
//        vc.contentSizeInPopup = CGSize(width: 300, height: 400)
//        vc.landscapeContentSizeInPopup = CGSize(width: 400, height: 200)
        
        let popup = STPopupController(rootViewController: vc)
        popup.style = STPopupStyle.bottomSheet
        
        if blurBackground {
            let blurEffect = UIBlurEffect.init(style: UIBlurEffectStyle.dark)
            if ((NSClassFromString("UIBlurEffect")) != nil) {
                popup.backgroundView = UIVisualEffectView(effect: blurEffect)
            }
        }
        
        DispatchQueue.main.async(execute: {
            popup.present(in: viewController)
        })
        
        return vc
    }
    
}
