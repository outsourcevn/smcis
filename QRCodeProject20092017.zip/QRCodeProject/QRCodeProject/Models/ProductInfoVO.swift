//
//  ProductInfoVO.swift
//  QRCodeProject
//
//  Created by Xuân Quỳnh Lê on 8/27/17.
//  Copyright © 2017 Quynhlx. All rights reserved.
//

import Foundation

class ProductInfoVO {
    var active = ""
    var location = ""
    var point = ""
    var total = ""
    
    var message = ""
    var status = ""
    var info = ""
    
    lazy var list = [ProductInfoVO]()
    
    func setSingleDataBy(item: NSDictionary) {
        message = item["message"] as? String ?? ""
        status = item["status"] as? String ?? ""
       
        
        let data = item["data"] as? [[String:Any]]
        
        
        active = (data?[0]["active"] as? NSString ?? "") as String
        info = (data?[0]["info"] as? NSString ?? "") as String
        location = (data?[0]["location"] as? NSString ?? "") as String
 
        
        point = (data?[0]["point"] as? NSString ?? "") as String
      
        
        total = (data?[0]["total"] as? NSString ?? "") as String
    }
    
}
