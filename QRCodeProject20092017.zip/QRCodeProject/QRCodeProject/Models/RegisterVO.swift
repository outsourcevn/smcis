
//
//  RegisterVO.swift
//  QRCodeProject
//
//  Created by Xuân Quỳnh Lê on 8/27/17.
//  Copyright © 2017 Quynhlx. All rights reserved.
//

import Foundation

class RegisterVO {
    var message = ""
    var status = ""
    var user_id = ""
    
    lazy var list = [RegisterVO]()
    
    func setSingleDataBy(item: NSDictionary) {
        message = item["message"] as? String ?? ""
        status = item["status"] as? String ?? ""
        

        
        let results = item["data"] as! [[String:Any]]
        

        user_id = results[0]["user_id"] as? String ?? ""
        

    }
    
}
