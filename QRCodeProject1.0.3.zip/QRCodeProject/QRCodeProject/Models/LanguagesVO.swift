//
//  LanguagesVO.swift
//  QRCodeProject
//
//  Created by Xuân Quỳnh Lê on 9/3/17.
//  Copyright © 2017 Quynhlx. All rights reserved.
//

import Foundation
import SwiftyJSON

struct LanguagesVO {
    let changeLanguageText : String
    let changeLanguageNoteText : String
    let changeLanguageViText : String
    let changeLanguageEnText : String
    
    let sysLanguage : String = MCLocalization.sharedInstance.language!
    
    init?(json: JSON) {
        guard
            let changeLanguage = json["str_change_language"][sysLanguage].string,
            let changeLanguageNote = json["str_change_language_note"][sysLanguage].string,
            let changeLanguageVi = json["str_change_language_vi"][sysLanguage].string,
            let changeLanguageEn = json["str_change_language_en"][sysLanguage].string
            else {return nil}
        
        self.changeLanguageText = changeLanguage
        self.changeLanguageNoteText = changeLanguageNote
        self.changeLanguageViText = changeLanguageVi
        self.changeLanguageEnText = changeLanguageEn
        
    }
}
