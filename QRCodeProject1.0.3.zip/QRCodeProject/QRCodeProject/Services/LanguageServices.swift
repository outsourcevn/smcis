//
//  LanguageServices.swift
//  QRCodeProject
//
//  Created by Xuân Quỳnh Lê on 9/3/17.
//  Copyright © 2017 Quynhlx. All rights reserved.
//

import Foundation
import SwiftyJSON

class LanguageServices {
    var alertJson: JSON = JSON.null
    
    static let shared = LanguageServices()
    private init() {}
    
    func getLocalLanguages() -> LanguagesVO {
        //load languages for alert
        
        if let file = Bundle.main.path(forResource: "local-en-vi", ofType: "json") {
            do {
                let data = try Data(contentsOf: URL(fileURLWithPath: file))
                let json = try JSON(data: data)
                
                self.alertJson = json
                
                print(json)
                
                
                
            } catch {
                self.alertJson = JSON.null
            }
        } else {
            self.alertJson = JSON.null
        }
        
        return LanguagesVO(json: alertJson)!
    }
}
