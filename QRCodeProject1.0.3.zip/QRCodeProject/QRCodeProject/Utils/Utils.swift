//
//  Utils.swift
//  QRCodeProject
//
//  Created by Xuân Quỳnh Lê on 8/27/17.
//  Copyright © 2017 Quynhlx. All rights reserved.
//

import Foundation
import UIKit
import MBProgressHUD

class Utils {
    //status 
    static let SUCCESS = "success"
    static let FAILED = "failed"
    
    static let baseServerAPI = "http://api.smartcheck.vn/Home/"
    static let web_reset_pass = "http://api.smartcheck.vn/home/reset"
    static let webHome = "http://smartcheck.vn/"
    static let lang = "vi"
    
    static let defaults = UserDefaults.standard
    
    //tutorial
    static func setTutorialShow(show: Bool) {
        defaults.set(show, forKey: "tutorialShow")
        
    }
    
    static func getTutorialShow() -> Bool {
        return defaults.object(forKey: "tutorialShow") as? Bool ?? false
    }
    
    //set - get local avaribles
    static func setLoginStatus(status: Bool) {
        defaults.set(status, forKey: "loginStatus")
        
    }
    
    static func getLoginStatus() -> Bool {
        return defaults.object(forKey: "loginStatus") as? Bool ?? false
    }
    
    //language
    static func setLanguages(status: String) {
        defaults.set(status, forKey: "lang")
        
    }
    
    static func getLanguages() -> String {
        return defaults.object(forKey: "lang") as? String ?? "vi"
    }
    //
    
    static func setUserId(status: String) {
        defaults.set(status, forKey: "user_id")
        
    }
    
    static func getUserId() -> String {
        return defaults.object(forKey: "user_id") as? String ?? ""
    }
    
    static func isValidEmail(email: String) -> Bool {
        let REGEX: String
        REGEX = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,6}"
        return NSPredicate(format: "SELF MATCHES %@", REGEX).evaluate(with: email)
    }
    
    static func alertWithTitle(title: String!, message: String, ViewController: UIViewController, toFocus:UITextField) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        let action = UIAlertAction(title: "OK", style: UIAlertActionStyle.cancel,handler: {_ in
            toFocus.becomeFirstResponder()
        });
        alert.addAction(action)
        ViewController.present(alert, animated: true, completion:nil)
    }
    
    static func showMessage(title: String?, message: String?) {
        let alert = UIAlertController.init(title: title, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction.init(title: "OK", style: .default, handler: { (action) in
            alert.dismiss(animated: true, completion: nil)
        }))
        UIApplication.shared.keyWindow?.rootViewController?.present(alert, animated: true, completion: nil)
    }
    
    static func showHUD(title: String?, view: UIView) {
        if let title = title {
            let hud = MBProgressHUD.showAdded(to: view, animated: true)
            hud.label.text = title
        } else {
            MBProgressHUD.showAdded(to: view, animated: true)
        }
    }
    
    static func hideHUD(view: UIView) {
        MBProgressHUD.hide(for: view, animated: true)
    }
}

extension String {
    func trim() -> String {
        return self.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines)
    }
    
    func index(of string: String, options: CompareOptions = .literal) -> Index? {
        return range(of: string, options: options)?.lowerBound
    }
    func endIndex(of string: String, options: CompareOptions = .literal) -> Index? {
        return range(of: string, options: options)?.upperBound
    }
    func indexes(of string: String, options: CompareOptions = .literal) -> [Index] {
        var result: [Index] = []
        var start = startIndex
        while let range = range(of: string, options: options, range: start..<endIndex) {
            result.append(range.lowerBound)
            start = range.upperBound
        }
        return result
    }
    func ranges(of string: String, options: CompareOptions = .literal) -> [Range<Index>] {
        var result: [Range<Index>] = []
        var start = startIndex
        while let range = range(of: string, options: options, range: start..<endIndex) {
            result.append(range)
            start = range.upperBound
        }
        return result
    }
    
    //right is the first encountered string after left
    func between(_ left: String, _ right: String) -> String? {
        guard
            let leftRange = range(of: left), let rightRange = range(of: right, options: .backwards)
            , left != right && leftRange.upperBound < rightRange.lowerBound
            else { return nil }
        
        let sub = self.substring(from: leftRange.upperBound)
        let closestToLeftRange = sub.range(of: right)!
        return sub.substring(to: closestToLeftRange.lowerBound)
    }
    
    var length: Int {
        get {
            return self.characters.count
        }
    }
    
    func substring(to : Int) -> String? {
        if (to >= length) {
            return nil
        }
        let toIndex = self.index(self.startIndex, offsetBy: to)
        return self.substring(to: toIndex)
    }
    
    func substring(from : Int) -> String? {
        if (from >= length) {
            return nil
        }
        let fromIndex = self.index(self.startIndex, offsetBy: from)
        return self.substring(from: fromIndex)
    }
    
    func substring(_ r: Range<Int>) -> String {
        let fromIndex = self.index(self.startIndex, offsetBy: r.lowerBound)
        let toIndex = self.index(self.startIndex, offsetBy: r.upperBound)
        return self.substring(with: Range<String.Index>(uncheckedBounds: (lower: fromIndex, upper: toIndex)))
    }
    
    func character(_ at: Int) -> Character {
        return self[self.index(self.startIndex, offsetBy: at)]
    }
}
