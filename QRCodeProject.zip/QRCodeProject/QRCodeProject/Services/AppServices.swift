//
//  AppServices.swift
//  QRCodeProject
//
//  Created by Xuân Quỳnh Lê on 8/27/17.
//  Copyright © 2017 Quynhlx. All rights reserved.
//

import Foundation
import Alamofire

class AppServices {
    //public string register(string name, string email, string phone, string pass, long? user_id, double? key)
    
    static func requestRegister(name: String, email: String, phone: String, pass: String, user_id:  Int64, key: Int64, completed: @escaping (_ error: Error?, _ resData: RegisterVO?) -> String) {
        let urlRequest = Utils.baseServerAPI + "register"
        let params = [ "name"     : name,
                      "email"        : email,
                      "phone"   : phone,
                      "pass"  : pass,
                      "user_id"  : user_id,
                      "key"  : key] as [String : Any]
        
        Alamofire.request(urlRequest, method: .post, parameters: params).responseJSON { (response) in
            switch response.result {
            case .success(let JSON):
                print("RESPONSE: \(JSON)")
                
                let dataVO = RegisterVO()
                let result = JSON as! NSDictionary
                dataVO.setSingleDataBy(item: result)
                
                
                
//                let listOfVideo = VideoModel()
//                let result = JSON as! NSDictionary
//                listOfVideo.setListVideoBy(response: result)
//                let items = result["items"] as! NSArray
//                for perItem in items {
//                    let videoTemp = VideoModel()
//                    videoTemp.setSingleDataBy(data: perItem as! NSDictionary)
//                    listOfVideo.listVideos.append(videoTemp)
//                }

                completed(nil, dataVO)
 
                break
                
            case .failure(let error):
                completed(error, nil)
                break
            }
        }
    }
    
    //public string login(string phone, string pass, double? key)
    static func requestLogin(phone: String, pass: String, key: Int64, completed: @escaping (_ error: Error?, _ resData: LoginVO?) -> String) {
        let urlRequest = Utils.baseServerAPI + "login"
        let params = [
                       "phone"   : phone,
                       "pass"  : pass,
                       "key"  : key] as [String : Any]
        
        Alamofire.request(urlRequest, method: .post, parameters: params).responseJSON { (response) in
            switch response.result {
            case .success(let JSON):
                                print("RESPONSE: \(JSON)")
                
                let dataVO = LoginVO()
                let result = JSON as! NSDictionary
                dataVO.setSingleDataBy(item: result)
                
                completed(nil, dataVO)
                break
                
            case .failure(let error):
                completed(error, nil)
                break
            }
        }
    }
    
    //public string check(string guid,long? user_id,double lon, double lat,string address, double? key)
    static func requestCheckInfo(guid: String, user_id: Int64, lon: Double, lat: Double, address: String, key: Int64, completed: @escaping (_ error: Error?, _ resData: ProductInfoVO?) -> String) {
        let urlRequest = Utils.baseServerAPI + "check"
        let params = [
            "guid"   : guid,
            "user_id"  : user_id,
            "lon"  : lon,
            "lat"  : lat,
            "address"  : address,
            "key"  : key] as [String : Any]
        
        Alamofire.request(urlRequest, method: .post, parameters: params).responseJSON { (response) in
            switch response.result {
            case .success(let JSON):
                print("RESPONSE: \(JSON)")

                let dataVO = ProductInfoVO()
                let result = JSON as! NSDictionary
                dataVO.setSingleDataBy(item: result)
                
                completed(nil, dataVO)
                break;
                
            case .failure(let error):
                completed(error, nil)
                break
            }
        }
    }
}
