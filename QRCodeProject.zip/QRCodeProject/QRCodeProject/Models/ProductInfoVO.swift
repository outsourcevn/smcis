//
//  ProductInfoVO.swift
//  QRCodeProject
//
//  Created by Xuân Quỳnh Lê on 8/27/17.
//  Copyright © 2017 Quynhlx. All rights reserved.
//

import Foundation

class ProductInfoVO {
    var active = ""
    var location = ""
    var point = ""
    var total = ""
    
    var message = ""
    var status = ""
    
    lazy var list = [ProductInfoVO]()
    
    func setSingleDataBy(item: NSDictionary) {
        message = item["message"] as? String ?? ""
        status = item["status"] as? String ?? ""
        
        print("message: \(message)")
        print("status: \(status)")
        
        let data = item["data"] as? [[String:Any]]
        
        print("results: \(String(describing: data))")
        
        active = (data?[0]["active"] as? NSString ?? "") as String
        print("active: \(active)")
        
        location = (data?[0]["location"] as? NSString ?? "") as String
        print("location: \(location)")
        
        point = (data?[0]["point"] as? NSString ?? "") as String
        print("point: \(point)")
        
        total = (data?[0]["total"] as? NSString ?? "") as String
        print("total: \(total)")
    }
    
}
